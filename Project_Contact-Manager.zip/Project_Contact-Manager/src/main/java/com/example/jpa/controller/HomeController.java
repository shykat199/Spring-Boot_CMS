package com.example.jpa.controller;

import java.util.Random;

import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.jpa.HelperMessage.Message;
import com.example.jpa.mailservice.EmailService;
import com.example.jpa.repo.UserRepository;
import com.example.jpa.userEntities.User;

@Controller
public class HomeController {

    Random random = new Random(1000);

    @Autowired
    private EmailService emailService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // to save data into db we need object of dao
    @Autowired
    private UserRepository userRepository;

    @RequestMapping("/")
    public String home(Model model) {
        model.addAttribute("title", "Home - Smart Contact Manager");
        return "home";
    }

    @RequestMapping("/about")
    public String about(Model model) {
        model.addAttribute("title", "About - Smart Contact Manager");
        return "about";
    }

    @RequestMapping("/signup")
    public String signup(Model model) {
        model.addAttribute("title", "Register - Smart Contact Manager");

        model.addAttribute("user", new User()); // sending blank user object for every new registration.
        return "signup";
    }

    // handler for registering user
    // we are going to accept data with the @ModelAttribute
    @RequestMapping(value = "/do_register", method = RequestMethod.POST)
    // fields that match with form object and user object, that values will
    // automatically come here and for checkout we have written separately.
    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result1,
            @RequestParam(value = "agreement", defaultValue = "false") boolean agreement, Model model,
            HttpSession session) {

        try {
            if (!agreement) {
                System.out.println("You have not agree the terms and conditions");
                throw new Exception("You have not agree the terms and conditions");
            }

            // checking for errors.
            if (result1.hasErrors()) {
                System.out.println("ERROR " + result1.toString());
                model.addAttribute("user", user);
                return "signup";
            }

            user.setRole("ROLE_USER");
            user.setEnabled(true);
            user.setImageUrl("default.png");

            // when user comes for signup, encode it and store in user.
            user.setPassword(passwordEncoder.encode(user.getPassword()));

            System.out.println("Agreement " + agreement);
            System.out.println("USER " + user);

            User result = this.userRepository.save(user); // this will help into db and also it will return its object.
            model.addAttribute("user", new User());

            // if everything goes OK, we pass notification as alert.
            String sessionId = session.getId();
            System.out.println("[session-id]: " + sessionId);

            // session.setAttribute("message", new Message("Registration Successful !",
            // "alert-success"));
            session.setAttribute("message", new Message("Registration Successful !", "alert-success"));
            return "signup";

        } catch (Exception e) {
            e.printStackTrace();
            // now showing error to user, we require session.
            model.addAttribute("user", user);
            session.setAttribute("message", new Message("Something went wrong!!!" + e.getMessage(), "alert-danger"));
            return "signup";
        }

    }

    // handler for custom login page
    @GetMapping("/signin")
    public String customLogin(Model model) {
        model.addAttribute("title", "Login page");
        return "login";
    }

    // handler for custom login page
    @GetMapping("/forget")
    public String forgetPassForm(Model model) {
        model.addAttribute("title", "Forget-password");
        return "forget_email_form";
    }

    // handler for custom login page

    @PostMapping("/send-otp")
    public String sendOTP(@RequestParam("email") String email, HttpSession session, Model model)
            throws MessagingException {

        model.addAttribute("title", "varify otp");

        System.out.println("Email :" + email);

        // generate otp of 4 digit
        int otp = random.nextInt(999999);

        System.out.println("OTP :" + otp);

        // return "varify_otp";

        String sudject = "OTP from SCM";
        String message = "" + "<div style='border:1px solid #e2e2e2;padding:20px'>" + "<h1>" + "OTP is- " + "<b>" + otp
                + "</n>" + "</h1>" + "</div>";
        String to = email;

        // code to send OTP

        boolean flag = this.emailService.sendEmail(message, sudject, to);

        if (flag) {

            session.setAttribute("myotp", otp);
            session.setAttribute("email", email);

            return "varify_otp";

        } else {

            session.setAttribute("message", "Check mail id...!!!");
            return "forget_email_form";

        }

    }

    // verify otp
    @PostMapping("/verify-otp")
    public String verifyOpt(@RequestParam("otp") int otp, HttpSession session) {

        int myOtp = (int) session.getAttribute("myotp");
        String email = (String) session.getAttribute("email");

        if (myOtp == otp) {

            User user = this.userRepository.getUserByUserName(email);

            if (user == null) {
                // send error

                session.setAttribute("message", "User doesnot exis with the email...!!!");
                return "forget_email_form";

            } else {
                // send change password form
            }

            return "password_change_form";
        } else {

            session.setAttribute("message", "You have entered wrong otp");
            return "varify_otp";
        }

    }

    // change password

    @PostMapping("/change-password")
    public String changePassword(@RequestParam("newPassword") String newPassword, HttpSession session) {

        String email = (String) session.getAttribute("email");
        User user = this.userRepository.getUserByUserName(email);

        user.setPassword(passwordEncoder.encode(newPassword));
        this.userRepository.save(user);

        // session.setAttribute("message", "You have entered wrong otp");

        return "redirect:/signup?change=password changed successfully....";
    }

}
