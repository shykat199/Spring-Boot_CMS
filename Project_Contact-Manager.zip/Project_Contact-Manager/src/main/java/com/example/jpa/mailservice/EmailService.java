package com.example.jpa.mailservice;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

@Service
public class EmailService {

    public boolean sendEmail(String message, String subject, String to) throws MessagingException {

        // gmail host

        boolean f = false;

        String from = "shykatroybdku199@gmail.com";

        String host = "smtp.gmail.com";

        // get the system property
        Properties properties = System.getProperties();
        System.out.println("Properties:- " + properties);

        // setting info about property object

        // set host
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        properties.put("mail.smtp..ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");

        // Step:1- get session object from mail add
        Session session = Session.getInstance(properties, new Authenticator() {

            @Override
            protected PasswordAuthentication getPasswordAuthentication() {

                return new PasswordAuthentication("shykatroybdku199@gmail.com", "shykat@199");

            }

        });

        session.setDebug(true);

        // Step:2- Compose the message[text,multi-media]
        MimeMessage myMessage = new MimeMessage(session);
        try {

            // from email
            myMessage.setFrom(from);

            // add recipient

            myMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            // add subject

            myMessage.setSubject(subject);

            // add message

            // myMessage.setText(message);
            myMessage.setContent(message, "text/html");

            // Step:3- sending
            Transport.send(myMessage);

            System.out.println("Sent successfully..............");

            f = true;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return f;
    }

}
