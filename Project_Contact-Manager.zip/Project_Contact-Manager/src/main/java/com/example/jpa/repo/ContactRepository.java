package com.example.jpa.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.jpa.contactEntities.Contact;
import com.example.jpa.userEntities.User;

public interface ContactRepository extends JpaRepository<Contact, Integer> {

	// replacing List with Page, Pageable will have current page & records per page.
	// pagination
	@Query("from Contact as c where c.user.id =:userId")
	public Page<Contact> findContactsByUser(@Param("userId") int userId, Pageable pageable);

	// create search bar method by name
	public List<Contact> findByNameContainingAndUser(String name, User user);

}
